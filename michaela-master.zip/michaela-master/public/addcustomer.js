function Homepage() {
  window.location.replace("index.html");
}
