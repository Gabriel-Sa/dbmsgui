function AddCustomer()
{
    window.location.replace("addcustomer.html");
}
function AddVehicle()
{
    window.location.replace("addvehicle.html");
}
function AddReservation()
{
    window.location.replace("addreservation.html");
}
function ReturnVehicle()
{
    window.location.replace("returnvehicle.html");
}
function Homepage()
{
    window.location.replace("index.html");
}