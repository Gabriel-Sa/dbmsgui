DBMS GUI
In order to get postgres working with the system, you can just pull from the github. However
the specific steps are:
1. Install pg using npm
2. Install express using npm
3. Go into app.js and edit the database settings to match your username and password, everthing else
does not need to be changed.
Run using node app.js in terminal.
